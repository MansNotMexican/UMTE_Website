# UMTE_Website
University of Manitoba 2017 COMP3020 Group 4 Project.

 This project is to build a website for the students and staffs at University of Manitoba for exchanging used textbooks. 
 
